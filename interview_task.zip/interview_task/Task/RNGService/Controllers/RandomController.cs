﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Text;
using RNGService.Models;
using RNGService.Services;

namespace RNGService.Controllers;

[ApiController]
[Route("")]
public class RandomController : ControllerBase
{
    private readonly ILogger<RandomController> _logger;
    private readonly IRandomGenerator _generator;
    private readonly IUserStatisticsService _userStatisticsService;
    private readonly IHttpContextAccessor _context;

    public RandomController(ILogger<RandomController> logger, IRandomGenerator generator, IUserStatisticsService userStatisticsService, IHttpContextAccessor context)
    {
        _logger = logger;
        _generator = generator;
        this._userStatisticsService = userStatisticsService;
        this._context = context;
    }

    [HttpGet(Name = "GetRandom")]
    public async Task<ActionResult<RandomResult>> GetRandomAsync(int len = 32)
    {
        try
        {
            var bytes = _generator.GetBytes(len); 

            await _userStatisticsService.CacheUserStatistics(_context); 

            return Ok(new RandomResult
            {
                Random = bytes
            });
        }
        catch (Exception e)
        {
            return BadRequest(e.Message);
        }
    }
}
