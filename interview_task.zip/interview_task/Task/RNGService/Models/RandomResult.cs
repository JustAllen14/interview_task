namespace RNGService.Models {
    public class RandomResult {
        public IEnumerable<byte>? Random { get; set; }
    }
}
