﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Identity.Web;
using System.Collections.Concurrent;
using System.Security.Claims;

namespace RNGService.Services
{
    public class UserStatisticsService : IUserStatisticsService, IDisposable
    {
        private readonly IMemoryCache _cache;
        private readonly ConcurrentDictionary<string, byte> _users;

        public UserStatisticsService(IMemoryCache cache)
        {
            _users = new ConcurrentDictionary<string, byte>();
            _cache = cache;
        }

        public Task CacheUserStatistics(IHttpContextAccessor context)
        {
            var objectId = context.HttpContext?.User.Claims
                .FirstOrDefault(x => x.Type == ClaimConstants.ObjectId)?.Value;

            if (string.IsNullOrEmpty(objectId))
                return Task.CompletedTask;

            // Add user if not already tracked (value doesn't matter, use 0 as dummy)
            _users.TryAdd(objectId, 0);

            _cache.TryGetValue<int>(objectId, out var userStatistics);
            userStatistics++;
            _cache.Set(objectId, userStatistics, DateTimeOffset.UtcNow.AddMinutes(10));

            return Task.CompletedTask;
        }

        public async ValueTask<int> GetUserStatistics(IHttpContextAccessor context)
        {
            var objectId = context.HttpContext?.User.Claims
                .FirstOrDefault(x => x.Type == ClaimConstants.ObjectId)?.Value;

            if (string.IsNullOrEmpty(objectId))
                return 0;

            return await _cache.GetOrCreateAsync(objectId, entry =>
            {
                entry.AbsoluteExpiration = DateTimeOffset.UtcNow.AddMinutes(10);
                return Task.FromResult(0);
            });
        }

        public void Dispose()
        {
            if (!_users.IsEmpty)
            {
                _users.Clear();
            }
            if (_cache != null)
            {
                _cache.Dispose();
            }
        }
    }
}
