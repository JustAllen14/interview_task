using Microsoft.AspNetCore.Authorization;

namespace RNGService.Services
{

    public class CustomAuthorizationRequirement : IAuthorizationRequirement
    {
    }
}